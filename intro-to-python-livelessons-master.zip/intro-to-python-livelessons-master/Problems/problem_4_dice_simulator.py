"""
Randomly returns two numbers between 1 and 6
"""

# Generate two random integer between 1 and 6 (inclusive)

# Tell the user what the result was

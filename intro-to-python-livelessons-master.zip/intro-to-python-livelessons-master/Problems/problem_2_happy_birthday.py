"""
Ask for the user's name and then sing happy birthday to them.
"""

"""
Deal a hand of 5 cards
"""

suits = ['♠︎', '♣︎', '♥︎', '♦︎']
values = ['A', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'J', 'Q', 'K']

cards = []
hand = []


print(hand)

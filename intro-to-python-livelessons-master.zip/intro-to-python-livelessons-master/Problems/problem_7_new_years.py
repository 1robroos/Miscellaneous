"""
Start at 10 seconds and count down until 1 and then print "Happy New Year! 🎉"
"""

print('Happy New Year! 🎉')

"""
Given a temperature in Fahrenheit, return the temperature in Celsius
"""
# Ask for a temperature in Fahrenheit

# Calculate it in Celsius

# Tell the user what it is

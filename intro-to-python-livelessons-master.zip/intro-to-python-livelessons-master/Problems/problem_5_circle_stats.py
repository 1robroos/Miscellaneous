"""
Fill out the functions to calculate the area and circumference of a circle.
Print the result to the user.
"""


def area(r):
    pass


def circumference(r):
    pass


radius = input("Circle radius: ")

print('Area: {}')  # <-- Call the area function and print the result
print('Circumference: {}')  # <-- Call the circumference function and print

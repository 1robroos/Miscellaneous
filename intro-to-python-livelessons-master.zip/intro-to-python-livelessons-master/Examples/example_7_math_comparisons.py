x = 5
print(f'x == 5 is {x == 5}')
print(f'x == -5 is {x == -5}')
print(f'x > 4 is {x > 4}')
print(f'x > 5 is {x > 5}')
print(f'x >= 5 is {x >= 5}')
print(f'x < 6 is {x < 6}')
print(f'x < 5 is {x < 5}')
print(f'x <= 5 is {x < 5}')

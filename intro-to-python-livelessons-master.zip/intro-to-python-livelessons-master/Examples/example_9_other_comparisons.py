print(f"'i' in 'team' is {'i' in 'team'}")
print(f"'i' in 'win' is {'i' in 'win'}")

print(f'isinstance(10, int) is {isinstance(10, int)}')
print(f'isinstance(10.0, int) is {isinstance(10.0, int)}')

print(f"'HELLO'.isupper() is {'HELLO'.isupper()}")
print(f"'pAssW0rD1'.isalnum() is {'pAssW0rD1'.isalnum()}")
print(f"'pAssW0rD1'.isalpha() is {'pAssW0rD1'.isalpha()}")

print(f"'3.14'.isnumeric() is {'3.14'.isnumeric()}")
print(f"'1400'.isnumeric() is {'1400'.isnumeric()}")

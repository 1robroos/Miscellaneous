x = 3

while x >= 0:  # Will keep looping until condition is met
    print(x)
    x = x - 1


y = 0
while True:  # Will keep looping until it encounters a break
    print(y)
    y += 1
    if y == 10:
        break

import math


print('hello world')

print("hello world")

print('hello \n world')

print(2 + 2)

print(-20 + 2)

print(123 * 456)

print(1/2)  # Python 3 => 0.5; Python 2 => 1

print(1//2)  # Python 3 => 0; Python 2 => Error

print(5 % 2)  # Modulo => remainder after division

print(6 % 2)

print(3**3)

print(6.02e23)

print(math.e)

print(math.pi)

print(math.sin(0.5))

r = 2.5
print(math.pi * r**2)

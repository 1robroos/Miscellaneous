num_coconuts = 0
print('I have ' + str(num_coconuts) + ' coconuts')

num_coconuts = 5
print('I bought 5 coconuts and now have ' + str(num_coconuts))

num_coconuts += 10
print('I was given 10 coconuts and now I have ' + str(num_coconuts))

num_coconuts -= 8
print('I gave 8 coconuts away and now I have ' + str(num_coconuts))

num_coconuts = 'banana'
print('My coconuts turned into ' + num_coconuts)

num_bananas = 3
print('What is happening to my coconuts? ' + num_coconuts*num_bananas)

del num_coconuts
print('My coconuts don\'t exist anymore ' + str(num_coconuts))
